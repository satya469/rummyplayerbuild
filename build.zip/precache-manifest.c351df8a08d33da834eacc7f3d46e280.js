self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f56240c7835f6077d9622cb237c34c73",
    "url": "/index.html"
  },
  {
    "revision": "8b164e33dbf740adbe34",
    "url": "/static/css/10.834d426e.chunk.css"
  },
  {
    "revision": "7ff812648ba5e5f37b53",
    "url": "/static/css/12.3e68da18.chunk.css"
  },
  {
    "revision": "c1678148f01e757ad68e",
    "url": "/static/css/8.2e947bf2.chunk.css"
  },
  {
    "revision": "d9015512da15c658d24b",
    "url": "/static/css/9.d6ada732.chunk.css"
  },
  {
    "revision": "cb1242a25a21af86b076",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "13273b20a1621dd646ba",
    "url": "/static/js/0.78806507.chunk.js"
  },
  {
    "revision": "e45ada2e255eecdbcdf8",
    "url": "/static/js/1.9c5208c9.chunk.js"
  },
  {
    "revision": "8b164e33dbf740adbe34",
    "url": "/static/js/10.cfbbf732.chunk.js"
  },
  {
    "revision": "b7ac413bf8b0b759ff8d",
    "url": "/static/js/11.b1e59b6f.chunk.js"
  },
  {
    "revision": "7ff812648ba5e5f37b53",
    "url": "/static/js/12.087776ea.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/12.087776ea.chunk.js.LICENSE.txt"
  },
  {
    "revision": "bc12ef360fa57464822d",
    "url": "/static/js/13.e9c4271c.chunk.js"
  },
  {
    "revision": "cfc43eb16b126ee02c6c",
    "url": "/static/js/14.1037bfd4.chunk.js"
  },
  {
    "revision": "eac17cda1b64ecda21c3",
    "url": "/static/js/15.cadf238e.chunk.js"
  },
  {
    "revision": "cbd3c5553ae826a1da2d",
    "url": "/static/js/16.4ba96a0a.chunk.js"
  },
  {
    "revision": "8febe1d0361def4ac659",
    "url": "/static/js/17.8413927d.chunk.js"
  },
  {
    "revision": "1cfc6fa003080e07230a",
    "url": "/static/js/18.7f709ea0.chunk.js"
  },
  {
    "revision": "e98a41fc5caf5c22404c",
    "url": "/static/js/19.f6e27608.chunk.js"
  },
  {
    "revision": "c2c804177b9cf3e8c6a9",
    "url": "/static/js/2.e63b0139.chunk.js"
  },
  {
    "revision": "bb4067a57109d4286a00",
    "url": "/static/js/20.598489de.chunk.js"
  },
  {
    "revision": "c3a2bfbe0835127d8e00",
    "url": "/static/js/21.1d65dd3a.chunk.js"
  },
  {
    "revision": "b84bb0a5ae8a82d0ab17",
    "url": "/static/js/22.55b369fa.chunk.js"
  },
  {
    "revision": "04f10c478464361da048",
    "url": "/static/js/23.410d617d.chunk.js"
  },
  {
    "revision": "8d5475b435a18ea8343e",
    "url": "/static/js/24.a4f01da5.chunk.js"
  },
  {
    "revision": "c1790ae6998b2f6711ba",
    "url": "/static/js/25.23c57da6.chunk.js"
  },
  {
    "revision": "889dee855377dab2c7a8",
    "url": "/static/js/26.6821835d.chunk.js"
  },
  {
    "revision": "b98df6c9da8f0a5f7111",
    "url": "/static/js/27.7aada827.chunk.js"
  },
  {
    "revision": "50a94bd89fa1060a84dc",
    "url": "/static/js/28.0a090256.chunk.js"
  },
  {
    "revision": "e52cf5c40398642cf9da",
    "url": "/static/js/29.cae2ad03.chunk.js"
  },
  {
    "revision": "c815a321f913f95f5047",
    "url": "/static/js/3.bcc06beb.chunk.js"
  },
  {
    "revision": "6d7fc4142a7703112478",
    "url": "/static/js/30.a61d8001.chunk.js"
  },
  {
    "revision": "3aa6ae1ed0fbc51394c1",
    "url": "/static/js/31.af228ff0.chunk.js"
  },
  {
    "revision": "ed5e5447f2de20aa09e0",
    "url": "/static/js/32.0081ba3b.chunk.js"
  },
  {
    "revision": "cdab2e82b7d32cd8c8c8",
    "url": "/static/js/33.9c8d926a.chunk.js"
  },
  {
    "revision": "c1371bd9c5c61f8c8e5b",
    "url": "/static/js/34.d10e60ce.chunk.js"
  },
  {
    "revision": "5bbcffa6bf7a205f88a2",
    "url": "/static/js/35.f135a4f7.chunk.js"
  },
  {
    "revision": "c8173b6f27a56ba4b297",
    "url": "/static/js/36.765ea01a.chunk.js"
  },
  {
    "revision": "eacbdd8cc77ea7e07091",
    "url": "/static/js/37.70d2b44f.chunk.js"
  },
  {
    "revision": "bd80f897b59d202c5dd6",
    "url": "/static/js/38.def0c711.chunk.js"
  },
  {
    "revision": "0e70f03cba54a509ffa6",
    "url": "/static/js/39.1b16ea0b.chunk.js"
  },
  {
    "revision": "8e0ff6c0f9e913b826ab",
    "url": "/static/js/4.19d863d7.chunk.js"
  },
  {
    "revision": "2feee3e9710a44660690",
    "url": "/static/js/40.680140e7.chunk.js"
  },
  {
    "revision": "d2c2a74f9c10a0a88bc2",
    "url": "/static/js/41.23d5851b.chunk.js"
  },
  {
    "revision": "f6717a488f245c33bdcb",
    "url": "/static/js/42.5d1737a9.chunk.js"
  },
  {
    "revision": "e215e4afb92b9fa66cae",
    "url": "/static/js/43.2c138dd5.chunk.js"
  },
  {
    "revision": "58afe309432655596e6e",
    "url": "/static/js/44.414d710a.chunk.js"
  },
  {
    "revision": "c3f336cc90ebc76e4625",
    "url": "/static/js/45.fb1b53bb.chunk.js"
  },
  {
    "revision": "b0f2148ac0041f55ae24",
    "url": "/static/js/46.a4616b00.chunk.js"
  },
  {
    "revision": "4c1bef27e71f8c3fbc5b",
    "url": "/static/js/47.09b70b66.chunk.js"
  },
  {
    "revision": "6dca7950f452333d9a0d",
    "url": "/static/js/48.692648ed.chunk.js"
  },
  {
    "revision": "8a8a929e0012d13af7a7",
    "url": "/static/js/49.05866c66.chunk.js"
  },
  {
    "revision": "df4ef43c2117c6fd8dda",
    "url": "/static/js/50.1200b00c.chunk.js"
  },
  {
    "revision": "996bad5851630ba730ce",
    "url": "/static/js/7.49bb614b.chunk.js"
  },
  {
    "revision": "43a2d556b7dddb14367c8edca6b8ddc4",
    "url": "/static/js/7.49bb614b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c1678148f01e757ad68e",
    "url": "/static/js/8.280db17c.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/8.280db17c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d9015512da15c658d24b",
    "url": "/static/js/9.087192c2.chunk.js"
  },
  {
    "revision": "cb1242a25a21af86b076",
    "url": "/static/js/main.049d5355.chunk.js"
  },
  {
    "revision": "3a8da6ab7cabda694cbb",
    "url": "/static/js/runtime-main.091cdbc6.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);